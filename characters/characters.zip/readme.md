missing bases: J; Z
missing attatchments: B; F; J; K; Z;

the missing characters above have never appeared ¯\_(ツ)_/¯